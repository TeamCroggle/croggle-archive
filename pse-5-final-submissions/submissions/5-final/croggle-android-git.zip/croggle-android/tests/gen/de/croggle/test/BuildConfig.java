/** Automatically generated file. DO NOT MODIFY */
package de.croggle.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}