/*******************************************************************************
 * Copyright 2011 See AUTHORS file.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *	 http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.badlogic.gdx.backends.headless;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Net;
import com.badlogic.gdx.net.NetJavaImpl;
import com.badlogic.gdx.net.ServerSocket;
import com.badlogic.gdx.net.ServerSocketHints;
import com.badlogic.gdx.net.Socket;
import com.badlogic.gdx.net.SocketHints;

/**
 * Headless implementation of the {@link com.badlogic.gdx.Net} API, based on
 * LWJGL implementation
 * 
 * @author acoppes
 * @author Jon Renner
 */
public class HeadlessNet implements Net {

	NetJavaImpl netJavaImpl = new NetJavaImpl();

	@Override
	public void sendHttpRequest(HttpRequest httpRequest,
			HttpResponseListener httpResponseListener) {
		netJavaImpl.sendHttpRequest(httpRequest, httpResponseListener);
	}

	// @Override
	// public void cancelHttpRequest(HttpRequest httpRequest) {
	// netJavaImpl.cancelHttpRequest(httpRequest);
	// }

	@Override
	public ServerSocket newServerSocket(Protocol protocol, int port,
			ServerSocketHints hints) {
		// return new NetJavaServerSocketImpl(protocol, port, hints);
		return null;
	}

	@Override
	public Socket newClientSocket(Protocol protocol, String host, int port,
			SocketHints hints) {
		// return new NetJavaSocketImpl(protocol, host, port, hints);
		return null;
	}

	@Override
	public void openURI(String URI) {
		// try {
		// if (!GraphicsEnvironment.isHeadless()
		// && Desktop.isDesktopSupported()) {
		// if (Desktop.getDesktop().isSupported(Action.BROWSE)) {
		// Desktop.getDesktop().browse(java.net.URI.create(URI));
		// return;
		// }
		// }
		// } catch (Throwable t) {
		// Gdx.app.error("HeadlessNet", "Failed to open URI. ", t);
		// return;
		// }
		Gdx.app.error("HeadlessNet",
				"Opening URIs on this environment is not supported. Ignoring.");
	}
}
