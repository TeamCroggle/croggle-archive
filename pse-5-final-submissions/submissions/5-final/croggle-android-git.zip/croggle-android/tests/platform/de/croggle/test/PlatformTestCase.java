package de.croggle.test;

import android.test.AndroidTestCase;

public class PlatformTestCase extends AndroidTestCase {

}
