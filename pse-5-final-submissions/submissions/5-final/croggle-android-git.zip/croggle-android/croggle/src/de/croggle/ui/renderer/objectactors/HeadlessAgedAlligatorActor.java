package de.croggle.ui.renderer.objectactors;

import de.croggle.game.board.AgedAlligator;

class HeadlessAgedAlligatorActor extends AgedAlligatorActor {

	HeadlessAgedAlligatorActor(AgedAlligator alligator) {
		super(alligator);
	}

	@Override
	protected void initialize() {
	}

}
