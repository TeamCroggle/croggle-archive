package de.croggle.ui;

public interface ConfirmInterface {

	public void yes();

	public void no();
}
