package de.croggle.ui;

public interface NotificationCloseListener {
	
	public void onNotificationClose();

}
