package de.croggle.backends.sqlite;

public class SQLException extends RuntimeException {

}
